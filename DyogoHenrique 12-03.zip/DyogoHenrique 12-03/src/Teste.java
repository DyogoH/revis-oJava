import java.util.Scanner;

public class Teste {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe o nome do paciente:");
        String nomePaciente = scanner.nextLine();
        System.out.println("Informe o CPF do paciente:");
        String cpfPaciente = scanner.nextLine();
        System.out.println("Informe o motivo da internação:");
        String motivoInternacao = scanner.nextLine();
        System.out.println("Informe o valor da diária de internação:");
        double valorDiaria = scanner.nextDouble();
        System.out.println("Informe o nome do médico responsável:");
        String nomeMedico = scanner.next();
        System.out.println("Informe o nome do enfermeiro responsável:");
        String nomeEnfermeiro = scanner.next();
        System.out.println("Informe a quantidade de dias de internação:");
        int diasInternacao = scanner.nextInt();

        Paciente paciente = new Paciente(nomePaciente, cpfPaciente, motivoInternacao, valorDiaria); 
        Medico medico = new Medico(nomeMedico);
        Enfermeiro enfermeiro = new Enfermeiro(nomeEnfermeiro);

        Internacao internacao = new Internacao(paciente, medico, enfermeiro, motivoInternacao, valorDiaria, diasInternacao);

        System.out.println("Internação realizada com sucesso. ID da internação: " + internacao.getId());
        System.out.println("Valor total da internação: R$" + internacao.getValorTotalInternacao());
    }
}
