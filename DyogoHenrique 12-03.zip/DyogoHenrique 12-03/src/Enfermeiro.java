/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dyogo
 */
public class Enfermeiro {

    private String nome;

    public Enfermeiro(String nome) {
        this.nome = nome;
    }

    // Getter e setter omitidos para brevidade
}
   

