/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author dyogo
 */

   public class Paciente extends Pessoa {
    private String motivoInternacao;
    private double valorDiaria;
    private int diasInternacao;
    private double valorTotalInternacao;

    public Paciente(String nome, String cpf, String motivoInternacao, double valorDiaria) {
        super(nome, cpf);
        this.motivoInternacao = motivoInternacao;
        this.valorDiaria = valorDiaria;
    }

   
}
 

