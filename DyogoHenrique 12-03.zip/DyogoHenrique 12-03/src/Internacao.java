public class Internacao {

    private static int proximoId = 1;

    private int id;
    private Paciente paciente;
    private Medico medicoResponsavel;
    private Enfermeiro enfermeiroResponsavel;
    private String motivoInternacao;
    private double valorDiaria;
    private int diasInternacao;
    private double valorTotalInternacao;

    public Internacao(Paciente paciente, Medico medicoResponsavel, Enfermeiro enfermeiroResponsavel,
                     String motivoInternacao, double valorDiaria, int diasInternacao) {
        this.id = proximoId++;
        this.paciente = paciente;
        this.medicoResponsavel = medicoResponsavel;
        this.enfermeiroResponsavel = enfermeiroResponsavel;
        this.motivoInternacao = motivoInternacao;
        this.valorDiaria = valorDiaria;
        this.diasInternacao = diasInternacao;
        this.valorTotalInternacao = calcularValorTotalInternacao();
    }

    private double calcularValorTotalInternacao() {
        return valorDiaria * diasInternacao;
    }

    public String getId() {
        return String.valueOf(id);
    }

    public String getValorTotalInternacao() {
        return String.format("%.2f", valorTotalInternacao);
    }
}
